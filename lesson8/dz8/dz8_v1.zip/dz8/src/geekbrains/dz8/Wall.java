package geekbrains.dz8;

public class Wall implements Barrier {
    private String name;
    private int sizeObstacles;

    public Wall(String name, int sizeObstacles) {
        this.name = name;
        this.sizeObstacles = sizeObstacles;
    }

    @Override
    public void barrier(Action action) {
        action.actionJump(sizeObstacles);
    }
}
