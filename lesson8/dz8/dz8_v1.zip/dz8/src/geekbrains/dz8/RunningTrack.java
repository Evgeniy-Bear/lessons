package geekbrains.dz8;

public class RunningTrack implements Barrier {
    private String name;
    private int sizeObstacles;

    public RunningTrack(String name, int sizeObstacles) {
        this.name = name;
        this.sizeObstacles = sizeObstacles;
    }


    @Override
    public void barrier(Action action) {
        action.actionRun(sizeObstacles);
    }
}
