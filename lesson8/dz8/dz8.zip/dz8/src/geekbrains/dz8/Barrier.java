package geekbrains.dz8;

public interface Barrier {
    boolean barrier(Action action);
}
