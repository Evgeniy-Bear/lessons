package geekbrains.dz8;

public interface Running {
    void run(int length);
}
