package com.company.lesson5.animals;

public class Dog {
}
