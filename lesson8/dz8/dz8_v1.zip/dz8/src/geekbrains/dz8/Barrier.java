package geekbrains.dz8;

public interface Barrier {
    void barrier(Action action);
}
