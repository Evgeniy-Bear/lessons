package geekbrains.dz8;

public interface Action {
    boolean actionRun(int length);
    boolean actionJump(int length);
}
