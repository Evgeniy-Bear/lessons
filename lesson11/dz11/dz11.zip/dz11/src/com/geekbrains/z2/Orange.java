package com.geekbrains.z2;

public class Orange extends Fruit {
    public Orange(float weight) {
        super(weight);
    }
}
