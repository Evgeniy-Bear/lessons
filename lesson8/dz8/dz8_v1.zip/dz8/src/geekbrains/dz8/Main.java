package geekbrains.dz8;



import java.sql.Array;

public class Main {
    public static void main(String[] args) {
// participant участник obstacle препятствие

        Barrier[] barriers=new Barrier[4];
        Action[] participant = new Action[3];
        participant[0]=new Human("Human",100,2);
        participant[1]=new Robot("Robo",10,1);
        participant[2]=new Cat("Cat",20,3);


        barriers[0]=new RunningTrack("RunningTrack",10);
        barriers[1]=new RunningTrack("RunningTrack",100);
        barriers[2]=new Wall("Wall",2);
        barriers[3]=new Wall("Wall",3);


        Test test= new Test();


        for (int i = 0; i < participant.length; i++) {
            for (int j = 0; j < barriers.length; j++) {
                test.test(participant[i],barriers[j]);

            }

        }


    }
}
