package geekbrains.dz8;

public interface Action {
    void actionRun(int length);
    void actionJump(int length);
}
