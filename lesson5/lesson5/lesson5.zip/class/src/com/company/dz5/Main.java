package com.company.dz5;

public class Main {
}
