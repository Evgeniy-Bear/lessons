package com.geekbrains.z1;

import java.util.ArrayList;
import java.util.List;

public class AddList {
    public List<String> addList() {
        List<String> list = new ArrayList<>();
        list.add("кошка");
        list.add("собака");
        list.add("лошадь");
        list.add("росомаха");
        list.add("кошка");
        list.add("мышка");
        list.add("тигр");
        list.add("лось");
        list.add("тигр");
        list.add("тигр");

        return list;

    }
}
