package geekbrains.dz8;

public interface Jumping {
    void jump (int length);
}
