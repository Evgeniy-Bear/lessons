package com.geekbrains.z2;

public class Apple extends Fruit {
    public Apple(float weight) {
        super(weight);
    }
}
