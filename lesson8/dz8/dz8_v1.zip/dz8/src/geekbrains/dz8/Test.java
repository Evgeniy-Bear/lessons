package geekbrains.dz8;

public class Test {
    public void test (Action action, Barrier barrier){
     barrier.barrier(action);
    }
}
